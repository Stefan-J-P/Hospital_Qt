#ifndef MY_LIBS
#define MY_LIBS


#include <QDebug>
#include <QString>
#include <QVector>
#include <QDate>
#include <QPair>
#include <QObject>


#include <QWidget>
#include <QCoreApplication>
#include <QtWidgets>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QStackedLayout>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLineEdit>
#include <QMainWindow>
#include <QStackedLayout>
#include <QWidget>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QComboBox>
#include <QTableWidget>
#include <QWidget>
#include <QTableWidgetItem>

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHBoxLayout>

#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QtCore/QVariant>

#include <boost/optional.hpp>

#include <iostream>
#include <string>
#include <memory>
#include <set>
#include <fstream>
#include <ostream>
#include <sstream>
#include <regex>
#include <exception>

#endif // MY_LIBS

