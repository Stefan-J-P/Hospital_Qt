#include "panel_statistics.h"

// CONSTRUCTOR -----------------------------------------------------------------------------------
panel_statistics::panel_statistics(QWidget *parent) : QWidget(parent)
{
    table_1_ = new QTableWidget(1, 2, this);

    table_layout_1_ = new QHBoxLayout();
    table_layout_1_->addWidget(table_1_);

    main_layout_ = new QVBoxLayout();
    main_layout_->addLayout(table_layout_1_);

    setLayout(main_layout_);

//    cubesHeaderItem_1 = new QTableWidgetItem("Cubes");
//    cubesHeaderItem_2 = new QTableWidgetItem("Squares");
//    cubesHeaderItem_1->setIcon(QIcon(QPixmap(":/Images/cubed.png")));
//    cubesHeaderItem_1->setTextAlignment(Qt::AlignVCenter);
//    table_1_->setItem(0,0,cubesHeaderItem_1);
//    table_1_->setItem(0,1,cubesHeaderItem_1);


}

// DEESTRUCTOR ----------------------------------------------------------------------------------
panel_statistics::~panel_statistics()
{

}



/*
 * OSOBNY PANEL
 * - zrobic tabele w ktorej mamy wizyty uporzadkowane wedlug daty, dodatkowo pod albo nad panelem
 * zrobic dwa comboboxy, jeden zawiera date "od" a drugi zawiera date "do" i mozesz po wybraniu dat
 * wypisywac tylko te wizyty ktore sa w przedziale.
 *
 * Wizyty powinny sie wypisywac kiedy od razu wybierzesz date.
 * Powinna byc walidacja daty czy czasem data od nie jest wieksza niz data do i wtedy
 * message z bledem
 *
 */













